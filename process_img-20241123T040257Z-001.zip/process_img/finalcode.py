import cv2
import yaml
import numpy as np
from motpy import Detection, ModelPreset, MultiObjectTracker
from screeninfo import get_monitors  # Added library to get screen information

# Mapping of threshold types
THRESHOLD_TYPES = {
    "THRESH_BINARY": cv2.THRESH_BINARY,
    "THRESH_BINARY_INV": cv2.THRESH_BINARY_INV,
    "THRESH_TRUNC": cv2.THRESH_TRUNC,
    "THRESH_TOZERO": cv2.THRESH_TOZERO,
    "THRESH_TOZERO_INV": cv2.THRESH_TOZERO_INV,
    "ADAPTIVE_THRESH_MEAN_C": cv2.ADAPTIVE_THRESH_MEAN_C,
    "ADAPTIVE_THRESH_GAUSSIAN_C": cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
    "THRESH_OTSU": cv2.THRESH_OTSU
}

BLUR_TYPES = {
    "GAUSSIAN": cv2.GaussianBlur,
    "MEAN": cv2.blur
}

def load_config(config_path="config.yaml"):
    """
    Function to load the config file
    Args:
        config_path (str): Path to the config file
    Returns:
        dict: Configuration data
    """
    with open(config_path, 'r', encoding='utf-8') as file:
        data = yaml.safe_load(file)
    return data

def put_text(frame, config):
    """
    Function to put text on the frame.
    Args:
        frame (np.ndarray): The frame to be shown.
        config (dict): Configuration dictionary containing text details.
    """
    # Top-left corner texts
    cv2.putText(
        frame, 
        config.get('mssv', 'MSSV'), 
        (10, 60), 
        cv2.FONT_HERSHEY_SIMPLEX, 
        1, 
        (255, 255, 255), 
        2, 
        cv2.LINE_AA
    )
    cv2.putText(
        frame, 
        config.get('name', 'Name'), 
        (10, 30), 
        cv2.FONT_HERSHEY_SIMPLEX, 
        1, 
        (255, 255, 255), 
        2, 
        cv2.LINE_AA
    )
    
    # Bottom-left corner texts (counts)
    cv2.putText(
        frame, 
        f"Squares: {config.get('square_count', 0)}", 
        (10, frame.shape[0] - 30), 
        cv2.FONT_HERSHEY_SIMPLEX, 
        0.8, 
        (0, 255, 255), 
        2, 
        cv2.LINE_AA
    )
    cv2.putText(
        frame, 
        f"Circles: {config.get('circle_count', 0)}", 
        (10, frame.shape[0] - 10), 
        cv2.FONT_HERSHEY_SIMPLEX, 
        0.8, 
        (0, 255, 255), 
        2, 
        cv2.LINE_AA
    )

def show_this(frame, config, name="frame2"):
    """
    Function to show the frame.
    Args:
        frame (np.ndarray): The frame to be shown.
        config (dict): Configuration dictionary containing display settings.
        name (str): Window name.
    """
    w = config.get('width', 640)
    h = config.get('height', 480)
    frame_resized = cv2.resize(frame, (h, w))
    cv2.namedWindow(name, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(name, h, w)
    cv2.imshow(name, frame_resized)

def threshold(frame, config):
    """
    Function to threshold the frame.
    Args:
        frame (np.ndarray): The frame to be thresholded.
        config (dict): Configuration dictionary containing threshold parameters.
    Returns:
        tuple: (ret, cleaned_image, frame_threshold, contours)
    """
    type_threshold = 0
    for item in config.get('type', []):
        type_threshold += THRESHOLD_TYPES.get(item, 0)
    low = config.get('low', 127)
    high = config.get('high', 255)
    arena_size = config.get('arena_size', 500)
    iterations_close = config.get('iterations_close', 2)
    color = config.get('color', 255)
    thickness = config.get('thickness', 1)
    kernel_size = tuple(config.get('kernel_size', [5, 5]))
    kernel = np.ones(kernel_size, np.uint8)

    # Apply threshold
    ret, frame_threshold = cv2.threshold(frame, low, high, type_threshold)

    opened_image = cv2.erode(frame_threshold, kernel, iterations=2)
    closed_image = cv2.dilate(opened_image, kernel, iterations=6)

    # Find contours
    contours, _ = cv2.findContours(closed_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    cleaned_image = np.zeros_like(closed_image)

    for contour in contours:
        if cv2.contourArea(contour) > arena_size:
            cv2.drawContours(cleaned_image, [contour], -1, color, thickness=thickness)

    cleaned_image = cv2.cvtColor(cleaned_image, cv2.COLOR_GRAY2RGB)

    return ret, cleaned_image, frame_threshold, contours

def count_square_circle(frame, original_image, config, contours, tracker_square, tracker_circle, unique_square_ids, unique_circle_ids, counted_square_ids, counted_circle_ids):
    """
    Đếm số lượng hình vuông và hình tròn trong khung hình, chỉ đếm những đối tượng đã được theo dõi ít nhất 5 khung hình.

    Args:
        frame (np.ndarray): Khung hình đã qua xử lý ngưỡng.
        original_image (np.ndarray): Khung hình gốc trước khi xử lý.
        config (dict): Từ điển cấu hình chứa các tham số cho việc phân loại và theo dõi.
        contours (list): Danh sách các contour được tìm thấy từ hàm `threshold`.
        tracker_square (MultiObjectTracker): Trình theo dõi đối tượng cho hình vuông.
        tracker_circle (MultiObjectTracker): Trình theo dõi đối tượng cho hình tròn.
        unique_square_ids (set): Tập hợp lưu trữ các ID hình vuông duy nhất.
        unique_circle_ids (set): Tập hợp lưu trữ các ID hình tròn duy nhất.
        counted_square_ids (set): Tập hợp lưu trữ các ID hình vuông đã được đếm.
        counted_circle_ids (set): Tập hợp lưu trữ các ID hình tròn đã được đếm.

    Returns:
        np.ndarray: Khung hình đã được đánh dấu.
    """
    circle_threshold = config.get('circle', 0.71)  # Tỷ lệ tối thiểu để xác định là hình tròn
    square_threshold = config.get('square', 0.86)  # Tỷ lệ tối thiểu để xác định là hình vuông

    list_square = []
    list_circle = []

    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        
        if w > 250 and h > 250:  # Điều chỉnh ngưỡng nếu cần
            contour_area = cv2.contourArea(contour)
            bounding_box_area = w * h

            fill_ratio = contour_area / bounding_box_area

            # Kiểm tra số đỉnh (vertices) của contour
            perimeter = cv2.arcLength(contour, True)
            approx = cv2.approxPolyDP(contour, 0.04 * perimeter, True)

            if perimeter == 0:
                circularity = 0
            else:
                circularity = 4 * np.pi * (contour_area / (perimeter * perimeter))

            # Phân loại dựa trên tỷ lệ lấp đầy và độ tròn
            if fill_ratio > square_threshold and 4 <= len(approx) <= 8:
                # Xác định là hình vuông hoặc hình chữ nhật
                detection = Detection(box=[x, y, x + w, y + h])
                list_square.append(detection)
            elif circularity > circle_threshold:
                # Xác định là hình tròn
                detection = Detection(box=[x, y, x + w, y + h])
                list_circle.append(detection)

    # Bước các danh sách hình vuông và hình tròn qua trình theo dõi
    tracker_square.step(detections=list_square)
    tracker_circle.step(detections=list_circle)

    active_tracked_squares = tracker_square.active_tracks( min_steps_alive=8, max_staleness = 15)
    active_tracked_circles = tracker_circle.active_tracks(min_steps_alive=4, max_staleness = 15)

    # Vẽ bounding box và ID cho hình vuông
    for obj in active_tracked_squares:
        x1, y1, x2, y2 = map(int, obj.box)
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)  # Màu xanh lá cây cho hình vuông
        cv2.putText(frame, f'ID: {str(obj.id)[:5]}', (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
        if obj.id not in counted_square_ids:
            unique_square_ids.add(obj.id)
            counted_square_ids.add(obj.id)

    # Vẽ bounding box và ID cho hình tròn
    for obj in active_tracked_circles:
        x1, y1, x2, y2 = map(int, obj.box)
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 2)  # Màu đỏ cho hình tròn
        cv2.putText(frame, f'ID: {str(obj.id)[:5]}', (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 2)
    
        if obj.id not in counted_circle_ids:
            unique_circle_ids.add(obj.id)
            counted_circle_ids.add(obj.id)

    # Cập nhật số đếm vào config để hiển thị
    config['square_count'] = len(unique_square_ids)
    config['circle_count'] = len(unique_circle_ids)

    # Hiển thị số lượng hình vuông và hình tròn
    cv2.putText(frame, f"Squares: {config['square_count']}", (60, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
    cv2.putText(frame, f"Circles: {config['circle_count']}", (60, 200), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)

    return frame


def denoise(frame, config):
    """
    Function to denoise the frame using a low-pass (average) filter.
    Args:
        frame (np.ndarray): The frame to be denoised.
        config (dict): Configuration dictionary containing denoise parameters.
    Returns:
        np.ndarray: Denoised frame.
    """
    c = config.get('denoise_kernel_size', 31)
    low_pass_kernel = np.ones((c, c), dtype=np.float32) / (c * c)
    frame_denoised = cv2.filter2D(frame, -1, low_pass_kernel)
    return frame_denoised

def make_frame_show(frames=[], frame_size=(640, 480)):
    """
    Combines multiple frames into a single display frame.
    Args:
        frames (list of np.ndarray): List of frames to combine (should contain exactly 4 frames).
        frame_size (tuple): Desired size for each individual frame.
    Returns:
        np.ndarray: Combined frame.
    """
    required_frames = 4  # 2x2 grid
    # Ensure exactly 4 frames by adding blank frames if necessary
    while len(frames) < required_frames:
        blank_frame = np.zeros((frame_size[1], frame_size[0], 3), dtype=np.uint8)
        frames.append(blank_frame)

    for i in range(len(frames)):
        if len(frames[i].shape) == 2 or frames[i].shape[2] == 1:
            frames[i] = cv2.cvtColor(frames[i], cv2.COLOR_GRAY2RGB)
        frames[i] = cv2.resize(frames[i], frame_size)
    
    top_row = np.hstack((frames[0], frames[1]))
    bottom_row = np.hstack((frames[2], frames[3]))
    combined_frame = np.vstack((top_row, bottom_row))
    
    return combined_frame

def create_final_frame(total_squares, total_circles, frame_size=(640, 480)):
    """
    Creates a final frame displaying the total counts of squares and circles.
    Args:
        total_squares (int): Total number of squares counted.
        total_circles (int): Total number of circles counted.
        frame_size (tuple): Size of the frame (width, height).
    Returns:
        np.ndarray: Frame with the final counts displayed.
    """
    final_frame = np.zeros((frame_size[1], frame_size[0], 3), dtype=np.uint8)  # Black frame

    # Define text properties
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 1.5
    color_square = (0, 255, 0)  # Green
    color_circle = (0, 0, 255)  # Red
    thickness = 3

    # Calculate text size to center it
    text_square = f"Total Squares: {total_squares}"
    text_circle = f"Total Circles: {total_circles}"

    # Get text size
    (text_width_sq, text_height_sq), _ = cv2.getTextSize(text_square, font, font_scale, thickness)
    (text_width_ci, text_height_ci), _ = cv2.getTextSize(text_circle, font, font_scale, thickness)

    # Calculate positions
    pos_square = ((frame_size[0] - text_width_sq) // 2, (frame_size[1] // 2) - 30)
    pos_circle = ((frame_size[0] - text_width_ci) // 2, (frame_size[1] // 2) + 30)

    # Put text on the final frame
    cv2.putText(final_frame, text_square, pos_square, font, font_scale, color_square, thickness, cv2.LINE_AA)
    cv2.putText(final_frame, text_circle, pos_circle, font, font_scale, color_circle, thickness, cv2.LINE_AA)

    return final_frame

def get_screen_resolution():
    """
    Retrieves the primary monitor's resolution.
    Returns:
        tuple: (width, height) of the screen in pixels.
    """
    monitor = get_monitors()[0]  # Get the first monitor
    return (monitor.width, monitor.height)

def main():
    """
    Main processing flow for video.
    """
    # Load config
    config = load_config(r"C:\Users\phamnhat\Desktop\computer vision\process_img\process_img\config.yaml")  # Ensure the correct path
    video_path = config.get("load_video", {}).get('path')
    cap = cv2.VideoCapture(video_path)
    
    if not cap.isOpened():
        print(f"Error: Could not open video at path: {video_path}")
        return
    
    # Get original video properties
    frame_size_individual = (config.get('show_frame', {}).get('width', 640), 
                             config.get('show_frame', {}).get('height', 480))
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    
    # Get screen resolution
    screen_width, screen_height = get_screen_resolution()
    
    # Calculate optimal frame size for display (2x2 grid)
    # Ensure that the combined frame fits within the screen resolution with some margin
    margin = 100  # Pixels
    combined_width = min(frame_size_individual[0] * 2, screen_width - margin)
    combined_height = min(frame_size_individual[1] * 2, screen_height - margin)
    frame_size_combined = (combined_width, combined_height)
    
    # Initialize VideoWriter with MP4V codec
    output_path = config.get('save_frame', {}).get('out_path', 'output.mp4')
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # Change codec if necessary
    
    try:
        out = cv2.VideoWriter(
            output_path,
            fourcc, 
            fps,
            frame_size_combined
        )
        cv2.namedWindow('Video Processing Result', cv2.WINDOW_NORMAL)
        cv2.resizeWindow('Video Processing Result', frame_size_combined[0], frame_size_combined[1])
        
        # Initialize trackers outside the loop to maintain state across frames
        model_spec = ModelPreset.constant_acceleration_and_static_box_size_2d.value
        tracker_square = MultiObjectTracker(
            dt=1/fps,
            model_spec=model_spec,
            active_tracks_kwargs={'min_steps_alive': 5, 'max_staleness': 15},
            tracker_kwargs={'max_staleness': 12}
        )
        tracker_circle = MultiObjectTracker(
            dt=1/fps,
            model_spec=model_spec,
            active_tracks_kwargs={'min_steps_alive': 5, 'max_staleness': 15},
            tracker_kwargs={'max_staleness': 12}
        )
        
        # Initialize total counts and counted IDs
        unique_square_ids = set()
        unique_circle_ids = set()
        counted_square_ids = set()  # Set to track counted square IDs
        counted_circle_ids = set()  # Set to track counted circle IDs
        
        while True:
            ret, frame = cap.read()
            if not ret:
                print("End of video or error reading frame")
                break
            
            try:
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                blurred_frame = denoise(gray, config.get("blur", {}))
                ret_thresh, thresh_frame, pret_thresh_frame, contours = threshold(blurred_frame, config.get("threshold", {}))
                processed_frame = count_square_circle(
                    thresh_frame, 
                    frame, 
                    config.get("counter", {}), 
                    contours,
                    tracker_square,
                    tracker_circle,
                    unique_square_ids,
                    unique_circle_ids,
                    counted_square_ids,  # Pass the counted sets
                    counted_circle_ids
                )
                
                concatenated_frame = make_frame_show(
                    [frame, blurred_frame, pret_thresh_frame, processed_frame],
                    frame_size_individual
                )
                
                # Add text and overlays
                # Update config with current counts for display
                config['square_count'] = len(unique_square_ids)
                config['circle_count'] = len(unique_circle_ids)
                put_text(concatenated_frame, config)
                
                # Resize the concatenated frame to fit the combined frame size
                resized_concatenated_frame = cv2.resize(concatenated_frame, frame_size_combined)
                
                # Write the combined frame to the output video
                out.write(resized_concatenated_frame)
                
                # Display the combined frame
                cv2.imshow('Video Processing Result', resized_concatenated_frame)
                
            except Exception as e:
                print(f"Error processing frame: {str(e)}")
                continue
            
            # Check for exit key
            if cv2.waitKey(1) & 0xFF == ord('q'):
                print("User requested exit")
                break
        
        # After processing all frames or exiting early, display final counts
        print("Final Counts:")
        print(f"Total Squares: {len(unique_square_ids)}")
        print(f"Total Circles: {len(unique_circle_ids)}")
        
        # Create a final frame displaying the total counts
        final_frame = create_final_frame(len(unique_square_ids), len(unique_circle_ids), frame_size_individual)
        concatenated_final_frame = make_frame_show(
            [final_frame, final_frame, final_frame, final_frame],
            frame_size_individual
        )
        
        # Add text to the final frame
        # Reset config counts for the final display
        final_config = {
            'square_count': len(unique_square_ids),
            'circle_count': len(unique_circle_ids),
            'mssv': config.get('mssv', 'MSSV'),
            'name': config.get('name', 'Name')
        }
        put_text(concatenated_final_frame, final_config)
        
        # Resize the final concatenated frame to fit the combined frame size
        resized_final_frame = cv2.resize(concatenated_final_frame, frame_size_combined)
        
        out.write(resized_final_frame)
        
        cv2.imshow('Video Processing Result', resized_final_frame)
        cv2.waitKey(0)

    except Exception as e:
        print(f"Error in main loop: {str(e)}")
        
    finally:
        # Release resources
        print("Cleaning up...")
        cap.release()
        out.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
